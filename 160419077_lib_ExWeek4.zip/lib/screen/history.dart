import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class History extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: const Center(
        child: Text("This is the History screen"),
      )
    );
  }
}
